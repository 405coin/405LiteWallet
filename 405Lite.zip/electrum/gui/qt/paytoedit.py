
























from functools import partial
from typing import Optional, TYPE_CHECKING, Union

from PyQt6.QtCore import Qt, QTimer, QSize, QStringListModel
from PyQt6.QtCore import pyqtSignal
from PyQt6.QtGui import QFontMetrics, QFont, QContextMenuEvent
from PyQt6.QtWidgets import QTextEdit, QWidget, QLineEdit, QStackedLayout, QCompleter

from electrum.payment_identifier import PaymentIdentifier
from electrum.logging import Logger
from electrum.util import EventListener, event_listener

from . import util
from .util import MONOSPACE_FONT, GenericInputHandler, ColorScheme, add_input_actions_to_context_menu

if TYPE_CHECKING:
    from .send_tab import SendTab


frozen_style = "QWidget {border:none;}"
normal_style = "QPlainTextEdit { }"


class InvalidPaymentIdentifier(Exception):
    pass


class ResizingTextEdit(QTextEdit):

    textReallyChanged = pyqtSignal()
    resized = pyqtSignal()

    def __init__(self):
        QTextEdit.__init__(self)
        self._text = ''
        self.setAcceptRichText(False)
        self.textChanged.connect(self.on_text_changed)
        document = self.document()
        fontMetrics = QFontMetrics(document.defaultFont())
        self.fontSpacing = fontMetrics.lineSpacing()
        margins = self.contentsMargins()
        documentMargin = document.documentMargin()
        self.verticalMargins = margins.top() + margins.bottom()
        self.verticalMargins += self.frameWidth() * 2
        self.verticalMargins += documentMargin * 2
        self.heightMin = self.fontSpacing + self.verticalMargins
        self.heightMax = (self.fontSpacing * 10) + self.verticalMargins
        self.update_size()

    def on_text_changed(self):

        if self.toPlainText() != self._text:
            self._text = self.toPlainText()
            self.textReallyChanged.emit()
            self.update_size()

    def update_size(self):
        docLineCount = self.document().lineCount()
        docHeight = max(3, docLineCount) * self.fontSpacing
        h = docHeight + self.verticalMargins
        h = min(max(h, self.heightMin), self.heightMax)
        self.setMinimumHeight(int(h))
        self.setMaximumHeight(int(h))
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.verticalScrollBar().setHidden(docHeight + self.verticalMargins < self.heightMax)
        self.setLineWrapMode(QTextEdit.LineWrapMode.WidgetWidth)
        self.resized.emit()

    def sizeHint(self) -> QSize:
        return QSize(0, self.minimumHeight())


class PayToEdit(QWidget, Logger, GenericInputHandler, EventListener):
    paymentIdentifierChanged = pyqtSignal()
    textChanged = pyqtSignal()

    def __init__(self, send_tab: 'SendTab'):
        QWidget.__init__(self, parent=send_tab)
        Logger.__init__(self)
        GenericInputHandler.__init__(self)

        self._text = ''
        self._layout = QStackedLayout()
        self.setLayout(self._layout)

        self.send_tab = send_tab

        def text_edit_changed():
            text = self.text_edit.toPlainText()
            if self._text != text:

                self._text = text
                self.line_edit.setText(text)
                self.textChanged.emit()

        def text_edit_resized():
            self.update_height()

        def line_edit_changed():
            text = self.line_edit.text()
            if self._text != text:

                self._text = text
                self.text_edit.setPlainText(text)
                self.textChanged.emit()

        self.line_edit = QLineEdit()
        self.line_edit.textChanged.connect(line_edit_changed)
        self.text_edit = ResizingTextEdit()
        self.text_edit.setTabChangesFocus(True)
        self.text_edit.textReallyChanged.connect(text_edit_changed)
        self.text_edit.resized.connect(text_edit_resized)

        def on_completed(item: str):
            text = self._completer_contacts[1][self._completer_contacts[0].index(item)]
            self.try_payment_identifier(text)
            self.completer.popup().hide()

        self.completer = QCompleter()
        self.completer.setCompletionMode(QCompleter.CompletionMode.PopupCompletion)
        self.completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.completer.setFilterMode(Qt.MatchFlag.MatchContains)
        self.completer.activated.connect(on_completed)

        self.update_completer()

        self.line_edit.setCompleter(self.completer)

        self.textChanged.connect(self._handle_text_change)

        self._layout.addWidget(self.line_edit)
        self._layout.addWidget(self.text_edit)

        self._single_line_height = self.line_edit.sizeHint().height()
        self._multiline = False
        self.multiline = False

        self._is_paytomany = False
        self.line_edit.setFont(QFont(MONOSPACE_FONT))
        self.text_edit.setFont(QFont(MONOSPACE_FONT))
        self.send_tab = send_tab
        self.config = send_tab.config


        self.on_qr_from_camera_input_btn = partial(
            self.input_qr_from_camera,
            config=self.config,
            allow_multi=False,
            show_error=self.send_tab.show_error,
            setText=self.try_payment_identifier,
            parent=self.send_tab.window,
        )
        self.on_qr_from_screenshot_input_btn = partial(
            self.input_qr_from_screenshot,
            allow_multi=False,
            show_error=self.send_tab.show_error,
            setText=self.try_payment_identifier,
        )
        self.on_qr_from_file_input_btn = partial(
            self.input_qr_from_file,
            allow_multi=False,
            config=self.config,
            show_error=self.send_tab.show_error,
            setText=self.try_payment_identifier,
        )
        self.on_input_file = partial(
            self.input_file,
            config=self.config,
            show_error=self.send_tab.show_error,
            setText=self.try_payment_identifier,
        )

        self.text_edit.contextMenuEvent = partial(self.custom_context_menu_event, tl_edit=self.text_edit)
        self.line_edit.contextMenuEvent = partial(self.custom_context_menu_event, tl_edit=self.line_edit)

        self.edit_timer = QTimer(self)
        self.edit_timer.setSingleShot(True)
        self.edit_timer.setInterval(1000)
        self.edit_timer.timeout.connect(self._on_edit_timer)

        self.payment_identifier = None

        self.register_callbacks()
        self.destroyed.connect(lambda: self.unregister_callbacks())

    def custom_context_menu_event(self, e: 'QContextMenuEvent', *, tl_edit: Union[QTextEdit, QLineEdit]) -> None:
        m = tl_edit.createStandardContextMenu()
        m.addSeparator()
        add_input_actions_to_context_menu(self, m)
        m.exec(e.globalPos())

    @event_listener
    def on_event_contacts_updated(self):
        self.update_completer()

    def update_completer(self):
        self._completer_contacts = [], []
        for k, v in self.send_tab.wallet.contacts.items():
            self._completer_contacts[0].append(f'{v[1]} <{k}>')
            self._completer_contacts[1].append(k)

        self.completer.setModel(QStringListModel(self._completer_contacts[0]))

    @property
    def multiline(self):
        return self._multiline

    @multiline.setter
    def multiline(self, b: bool) -> None:
        if b is None:
            return
        self._multiline = b
        self._layout.setCurrentWidget(self.text_edit if b else self.line_edit)
        self.update_height()

    def update_height(self) -> None:
        if self.multiline:
            h = self._layout.currentWidget().sizeHint().height()
            self.setMinimumHeight(h)
            self.setMaximumHeight(h)
        else:
            if self._single_line_height:
                self.setMinimumHeight(self._single_line_height)
                self.setMaximumHeight(self._single_line_height)
            else:
                self.setMinimumHeight(0)
                self.setMaximumHeight(16777215)

    def set_single_line_height(self, height: int) -> None:
        self._single_line_height = max(0, height)
        if not self.multiline:
            self.setMinimumHeight(self._single_line_height)
            self.setMaximumHeight(self._single_line_height)

    def setText(self, text: str) -> None:
        if self._text != text:
            self.line_edit.setText(text)
            self.text_edit.setText(text)

    def setFocus(self, reason=Qt.FocusReason.OtherFocusReason) -> None:
        if self.multiline:
            self.text_edit.setFocus(reason)
        else:
            self.line_edit.setFocus(reason)

    def setToolTip(self, tt: str) -> None:
        self.line_edit.setToolTip(tt)
        self.text_edit.setToolTip(tt)

    def try_payment_identifier(self, text) -> None:

        pi = PaymentIdentifier(self.send_tab.wallet, text)
        if not pi.is_valid():
            raise InvalidPaymentIdentifier('Invalid payment identifier')
        self.set_payment_identifier(text)

    def set_payment_identifier(self, text) -> None:
        if self.payment_identifier and self.payment_identifier.text == text.strip():

            return

        self.payment_identifier = PaymentIdentifier(self.send_tab.wallet, text)


        if self.payment_identifier.is_multiline() and not self._is_paytomany:
            self.set_paytomany(True)



        self.setText(text)

        self.paymentIdentifierChanged.emit()

    def set_paytomany(self, b):
        self._is_paytomany = b
        self.multiline = b
        self.send_tab.paytomany_menu.setChecked(b)
        self.update_height()

    def toggle_paytomany(self) -> None:
        self.set_paytomany(not self._is_paytomany)

    def is_paytomany(self):
        return self._is_paytomany

    def setReadOnly(self, b: bool) -> None:
        self.line_edit.setReadOnly(b)
        self.text_edit.setReadOnly(b)

    def isReadOnly(self):
        return self.line_edit.isReadOnly()

    def setStyleSheet(self, stylesheet: str) -> None:
        self.line_edit.setStyleSheet(stylesheet)
        self.text_edit.setStyleSheet(stylesheet)

    def setFrozen(self, b) -> None:
        self.setReadOnly(b)
        self.setStyleSheet(ColorScheme.LIGHTBLUE.as_stylesheet(True) if b else '')

    def isFrozen(self):
        return self.isReadOnly()

    def do_clear(self) -> None:
        self.set_paytomany(False)
        self.setText('')
        self.setToolTip('')
        self.payment_identifier = None

    def setGreen(self) -> None:
        self.setStyleSheet(util.ColorScheme.GREEN.as_stylesheet(True))

    def setExpired(self) -> None:
        self.setStyleSheet(util.ColorScheme.RED.as_stylesheet(True))

    def _handle_text_change(self) -> None:
        if self.isFrozen():


            return


        pi = PaymentIdentifier(self.send_tab.wallet, self._text)
        if not pi.is_valid() or pi.need_resolve() or self.edit_timer.isActive():
            self.edit_timer.start()
        else:
            self.set_payment_identifier(self._text)

    def _on_edit_timer(self) -> None:
        if not self.isFrozen():
            self.set_payment_identifier(self._text)

#!/bin/bash











ZBAR_VERSION="bb05ec54eec57f8397cb13fb9161372a281a1219"


set -e

. "$(dirname "$0")/build_tools_util.sh" || (echo "Could not source build_tools_util.sh" && exit 1)

here="$(dirname "$(realpath "$0" 2> /dev/null || grealpath "$0")")"
CONTRIB="$here"
PROJECT_ROOT="$CONTRIB/.."

pkgname="zbar"
info "Building $pkgname..."

(
    cd "$CONTRIB"
    if [ ! -d zbar ]; then
        git clone https://github.com/mchehab/zbar.git
    fi
    cd zbar
    if ! $(git cat-file -e ${ZBAR_VERSION}) ; then
        info "Could not find requested version $ZBAR_VERSION in local clone; fetching..."
        git fetch --all
    fi
    git reset --hard
    git clean -dfxq
    git checkout "${ZBAR_VERSION}^{commit}"

    if [ "$BUILD_TYPE" = "wine" ] ; then
        echo "libzbar_la_LDFLAGS += -Wc,-static" >> zbar/Makefile.am
        echo "LDFLAGS += -Wc,-static" >> Makefile.am
    fi
    if ! [ -x configure ] ; then
        autoreconf -vfi || fail "Could not run autoreconf for $pkgname. Please make sure you have automake and libtool installed, and try again."
    fi
    if ! [ -r config.status ] ; then
        if [ "$BUILD_TYPE" = "wine" ] ; then

            AUTOCONF_FLAGS="$AUTOCONF_FLAGS \
                --with-x=no \
                --enable-video=yes \
                --with-jpeg=no \
                --with-directshow=yes \
                --disable-dependency-tracking"
        elif [ $(uname) == "Darwin" ]; then

            AUTOCONF_FLAGS="$AUTOCONF_FLAGS \
                --with-x=no \
                --enable-video=no \
                --with-jpeg=no"
        else

            AUTOCONF_FLAGS="$AUTOCONF_FLAGS \
                --with-x=yes \
                --enable-video=yes \
                --with-jpeg=yes"
        fi
        ./configure \
            $AUTOCONF_FLAGS \
            --prefix="$here/$pkgname/dist" \
            --enable-pthread=no \
            --enable-doc=no \
            --with-python=no \
            --with-gtk=no \
            --with-qt=no \
            --with-java=no \
            --with-imagemagick=no \
            --with-dbus=no \
            --enable-codes=qrcode \
            --disable-static \
            --enable-shared || fail "Could not configure $pkgname. Please make sure you have a C compiler installed and try again."
    fi
    make "-j$CPU_COUNT" || fail "Could not build $pkgname"
    make install || fail "Could not install $pkgname"
    . "$here/$pkgname/dist/lib/libzbar.la"
    host_strip "$here/$pkgname/dist/lib/$dlname"
    cp -fpv "$here/$pkgname/dist/lib/$dlname" "$PROJECT_ROOT/electrum" || fail "Could not copy the $pkgname binary to its destination"
    info "$dlname has been placed in the inner 'electrum' folder."
    if [ -n "$DLL_TARGET_DIR" ] ; then
        cp -fpv "$here/$pkgname/dist/lib/$dlname" "$DLL_TARGET_DIR/" || fail "Could not copy the $pkgname binary to DLL_TARGET_DIR"
    fi
)
